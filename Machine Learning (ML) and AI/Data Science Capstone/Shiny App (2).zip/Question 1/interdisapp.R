library(shiny)
library(tidyverse)
library(markdown)
library(bslib)
library(leaflet)
#library(rsconnect)
#rsconnect::deployApp(appDir = getwd(), appPrimaryDoc = "interdisapp.R", appFiles = NULL)

data <- read.csv("data/clean_with_names.csv")

variableimportancedata <- read.csv("data/modelvariableimportance.csv")

ui <- navbarPage(
  id = "navbar",
  title = "Great Barrier Reef Coral Restoration",
  theme = bs_theme(version = 5, bootswatch = "minty"),
  
  tabPanel("Home", 
            fluidPage(
              tags$head(
                tags$style(HTML("
        .image-container {
          position: relative;
          width: 100%;
          margin-bottom: 20px;
        }

        .hover-image {
          display: block;
          width: 100%;
          height: auto;
          border-radius: 12px;
        }

        .hover-text {
          position: absolute;
          top: 0;
          bottom: 0;
          left: 0;
          right: 0;
          background-color: rgba(0, 0, 0, 0.6);
          color: white;
          visibility: hidden;
          opacity: 0;
          transition: opacity 0.3s;
          display: flex;
          justify-content: center;
          align-items: center;
          font-size: 1rem;
          text-align: center;
          padding: 10px;
          border-radius: 12px;
        }

        .image-container:hover .hover-text {
          visibility: visible;
          opacity: 1;
        }
      "))
              ),
              
              h2("Our Purpose"),
              p("The Great Barrier Reef (GBR) coral coverage is in decline. Since 1985, live coral coverage across the whole Great Barrier Reef has declined by over 50% due to numerous influences, including coral bleaching, crown-of-thorns starfish and tropical cyclones [1]. However, rehabilitation and restoration to increase reef health and ensure its survival into the future are possible as long as environmental factors, the current reef state and future resilience are considered during planning. Therefore, our purpose was to develop an interactive tool that allows restoration teams the opportunity to look at the resilience of reefs and regions in the GBR and evaluate what environmental factors are causing the trends in resilience. This will therefore allow for guided suggestions for the implementation of restoration strategies, ultimately resulting in more targeted coral restoration and a decrease in the number of unsuccessful attempts."),
              br(),
              
              h4("Possible Implementation"),
              
              fluidRow(
                column(3,
                       div(class = "image-container",
                           img(src = "coralgardening.jpg", class = "hover-image"),
                           div(class = "hover-text", "Coral Gardening")
                       )
                ),
                column(3,
                       div(class = "image-container",
                           img(src = "coralrestoration.jpg", class = "hover-image"),
                           div(class = "hover-text", "Coral Restoration")
                       )
                ),
                column(3,
                       div(class = "image-container",
                           img(src = "heattolerant.jpg", class = "hover-image"),
                           div(class = "hover-text", "Heat Tolerant Coral Propergation")
                       )
                ),
                column(3,
                       div(class = "image-container",
                           img(src = "coralmonitoring.jpg", class = "hover-image"),
                           div(class = "hover-text", "Coral Monitoring")
                       )
                )
              ),
              
              br(),
              fluidRow(
                column(6,
                       tags$div(
                         tags$h4("Defining Resilience"),
                         tags$ul(
                           tags$li("Resilience is calculated by comparing the coral cover at each reef three years following the 2016 bleaching event relative to the year prior to the same event. It is then standardised using the historical maximum coral cover ever recorded at that specific reef."),
                           tags$li("The calculation was made off the definition of resilience in literature, which broadly defines reef resilience as the ability of the reef community to maintain or restore structure and function and remain in an equivalent ‘phase’ as before the coral mortality [2]."),
                           tags$li("Resilience can be influenced by a variety of factors, including, but not limited to, benthic cover, substrate type, wave dynamics, or the ocean chemistry present at that reef. Furthermore, anthropogenic factors, including temperature, pH, and excess nitrogen, may also play a role [2].")
                         )
                       )
                ),
                column(6,
                       tags$div(
                         tags$h4("Defining Regions"),
                         tags$ul(
                           tags$li("Our study divides the Great Barrier Reef (GBR) into distinct regions to understand their unique characteristics."),
                           tags$li("We've adopted the latitudinal boundaries for GBR regions as defined by Hughes et al. [3, 4]."),
                           tags$li("These boundaries are based on the historical heat exposure of different GBR areas."),
                           tags$li("Our defined regions are:"),
                           tags$ul(
                             tags$li("North GBR: 10°S – 15°S"),
                             tags$li("Central GBR: 15°S – 19°S"),
                             tags$li("Southern GBR: 19°S – 24°S")
                           ),
                           tags$li("Within these regions, the mid-shelf and outer-shelf zones are further defined using depth criteria established by the Australian Institute of Marine Science (AIMS).")
                         )
                       )
                )
              ),
              br(),
              fluidRow(
                column(3, card(h3("$10 trillion"), h6("a year is contributed globally due to coral reefs"))),
                column(3, card(h3("50%"), h6("decrease in live coral coverage since 1985"))),
                column(3, card(h3("8-degree"), h6("difference in heat tolerance within coral species"))),
                column(3, card(h3("33%"), h6("of coral gardening fails, often due to poor planning")))
              ),
              br(),
              h6("References:"),
              p("[1] De’ath, G., Fabricius, K., Sweatman, H. & Puotinen, M. (2012) The 27-year decline of coral cover on the Great Barrier Reef and its causes. Proceedings of the National Academy of Sciences, 109(44), 17995-17999."),
              p("[2] Obura, D. & Grimsditch, G. (2009) Resilience Assessment of coral reefs: Assessment protocol for coral reefs, focusing on coral bleaching and thermal stress. IUCN technical report."),
              p("[3] Hughes, T. P., Kerry, J. T., Álvarez-Romero, J. G., Baird, A. H., Connolly, S. R., Dixson, D. L., Ferreira, C. E., Figueira, W. F., Fortin, M. J., Heron, S. F., Holmes, G., Pandolfi, J. M., & Pratchett, M. S. (2019). Ecological memory modulates the cumulative impact of repeated marine heatwaves. Nature Climate Change, 9(12), 990–995."),
              p("[4] Hughes, T. P., Kerry, J. T., Connolly, S. R., Álvarez-Romero, J. G., Eakin, C. M., Heron, S. F., Gonzalez, M. A., & Moneghetti, J. (2021). Emergent properties in the responses of tropical corals to recurrent climate extremes. Current Biology, 31(23), 5393–5399.")
            )
  ),
  
  nav_menu("Region", 
           nav_panel("Northern", 
                     fluidPage(
                       h2("Northern Region of the GBR"), 
                       selectInput(
                         "shelfposition_northern", 
                         "Select Reef Shelf Position:", 
                         list("Middle Shelf" = "NM", "Outer Shelf" = "NO")
                       ),
                       fluidRow(
                         column(6, 
                                br(),
                                h4("Influential Environmental Variables"),
                                tableOutput("northern_table"),
                         ),
                         column(6, 
                                leafletOutput("northern_map", height = 400)
                                )
                       ),
                       h4("Significance and Implications for Restoration"),
                       uiOutput("northern_text"),
                       br(),
                       div(style = "text-align: center;",
                           actionButton("go_to_comparison", "Compare Regions of the GBR", class = "btn btn-primary")
                       ),
                       br()
                       )),
           nav_panel("Central", 
                       fluidPage(
                         h2("Central Region of the GBR"), 
                         selectInput(
                           "shelfposition_central", 
                           "Select Reef Shelf Position:", 
                           list("Middle Shelf" = "CM", "Outer Shelf" = "CO")
                         ),
                         fluidRow(
                           column(6, 
                                  br(),
                                  h4("Influential Environmental Variables"),
                                  tableOutput("central_table")
                                  ),
                           column(6, 
                                  leafletOutput("central_map", height = 400)
                           )
                         ),
                         h4("Significance and Implications for Restoration"),
                         uiOutput("central_text"),
                         br(),
                         div(style = "text-align: center;",
                             actionButton("go_to_comparison", "Compare Regions of the GBR", class = "btn btn-primary")
                         ),
                         br()
                       )),
           nav_panel("Southern", 
                     fluidPage(
                       h2("Southern Region of the GBR"), 
                       selectInput(
                         "shelfposition_southern", 
                         "Select Reef Shelf Position:", 
                         list("Middle Shelf" = "SM", "Outer Shelf" = "SO")
                       ),
                       fluidRow(
                         column(6, 
                                br(),
                                h4("Influential Environmental Variables"),
                                tableOutput("southern_table")
                         ),
                         column(6, 
                                leafletOutput("southern_map", height = 400)
                         )
                       ),
                       h4("Significance and Implications for Restoration"),
                       uiOutput("southern_text"),
                       br(),
                       div(style = "text-align: center;",
                           actionButton("go_to_comparison", "Compare Regions of the GBR", class = "btn btn-primary")
                       ),
                       br()
                     )),
  ),
  
  nav_panel("Comparison", 
            fluidPage(
              h2("Region Comparison"),
              fluidRow(
                column(12, card(p("This tool allows for a map distribution and pattern comparison between regions as well as a comparison of average resilience and the environmental variables influencing resilience in each region. Simply select the number of regions and which regions you would like to compare. Please note that variable importance should only be compared relative to within the region and only variable order of importance should be compared between regions.")))),
              selectInput("num_regions", "How many sectors do you want to compare?", choices = 2:4, selected = 2),
              uiOutput("comparison_ui")
            )
  )
)

server <- function(input, output, session) {
  
  output$northern_map <- renderLeaflet({
    req(input$shelfposition_northern)
    
    selected_data <- data %>%
      filter(sector == input$shelfposition_northern)
    
    pal <- colorNumeric("YlGnBu", domain = c(-100, 100))
    
    leaflet(selected_data) %>%
      addTiles() %>%
      addCircleMarkers(
        lng = ~longitude,
        lat = ~latitude,
        radius = 6,
        color = ~pal(rel_resilience),
        fillOpacity = 0.8,
        stroke = FALSE,
        label = ~paste0(
          "<strong>Reef Name: </strong>", english_name, "<br/>",
          "<strong>Reef ID: </strong>", name, "<br/>",
          "<strong>Relative Resilience: </strong>", rel_resilience
        ) %>% lapply(htmltools::HTML)
      )%>%
      addLegend(
        position = "bottomright",
        pal = pal,
        values = c(-100, 100),
        title = "Relative Resilience",
        labFormat = labelFormat(suffix = ""),
        opacity = 1
      )
  })
  
  output$northern_table <- renderTable({
    req(input$shelfposition_northern)  
    
    variableimportancedata %>%
      filter(Sector == input$shelfposition_northern) %>%
      select(Variable, Importance)%>%
      arrange(desc(Importance)) 
  })
  
  output$northern_text <- renderUI({
    req(input$shelfposition_northern)
    
    top_vars <- variableimportancedata %>%
      filter(Sector == input$shelfposition_northern) %>%
      arrange(desc(Importance)) %>%
      slice(1:3) %>%
      pull(Variable)
    
    explanation <- "<ul>"
    
    if ("Salinity " %in% top_vars) {
      explanation <- paste0(explanation, "<li><strong>Salinity:</strong><br/>
    <u>Significance:</u> the influence of salinity on live coral coverage may suggest the impact of mainland run-off into the reef system causing declines in salinity and possible coral bleaching or it could suggest a trend in cyclone related coral destruction which simultaneously leads to changes in ocean salinity over a short term.<br/>
    <u>Implications:</u> regions where salinity is an influential predictor of live coral cover should consider if this is due to runoff from the land and therefore how this can be accounted for. Reef monitoring at sites that meet this description is recommended. If the influence of salinity is due to extreme rainfall or cyclone events then coral restoration is recommended as these events are often short term and not predictable.</li>")
    }
    
    if ("pH " %in% top_vars) {
      explanation <- paste0(explanation, "<li><strong>pH:</strong><br/>
    <u>Significance:</u> the influence of pH on live coral coverage may reflect the impact of ocean acidification, which reduces the availability of carbonate ions needed for coral calcification. Lower pH levels can hinder coral growth and weaken skeletal structures, increasing susceptibility to environmental stressors. Alternatively, fluctuations in pH may indicate localized chemical changes driven by biological activity, terrestrial runoff, or upwelling events.<br/>
    <u>Implications:</u> regions where pH is an influential predictor of live coral cover should assess whether changes stem from long-term ocean acidification trends or short-term localized disturbances. If ocean acidification is the key driver, mitigation strategies such as reducing carbon emissions and improving marine carbonate buffering should be considered. Coral restoration efforts may focus on selecting resilient species that exhibit adaptation to lower pH conditions. If pH variations are linked to runoff, land management practices should be evaluated to minimize pollutant influx, and reef monitoring programs should be expanded to track chemical stability.</li>")
    }
    
    if ("Nitrogen " %in% top_vars) {
      explanation <- paste0(explanation, "<li><strong>Nitrogen:</strong><br/>
    <u>Significance:</u> the influence of nitrogen on live coral coverage may suggest the presence of algal blooms or excess anthropogenic run off from the mainland. Nitrogen if in correct amounts may have a positive relationship with coral growth how this is a delicate balance that is often disturbed by agricultural runoff and catchment erosion which can intensify crown-of-thorns starfish outbreaks and reduce post-bleaching recovery rates.<br/>
    <u>Implications:</u> prior to coral restoration, the cause of nitrogen influencing live coral coverage should be explored and solved if its an ongoing anthropogenic issue as any restoration may fail without this type of intervention. Coral monitoring should also be a large focus for this region.</li>")
    }
    
    if ("Dissolved oxygen " %in% top_vars) {
      explanation <- paste0(explanation, "<li><strong>Dissolved Oxygen:</strong><br/>
    <u>Significance:</u> the negative influence of dissolved oxygen on live coral coverage may suggest the presence of algal bloom or low flow conditions which remove oxygen from the ecosystem and alter coral respiration and energy supply causing coral dealth.<br/>
    <u>Implications:</u> regions where dissolved oxygen is influencing live coral coverage should be explored as to what the cause is. If the relationship is positive due to dissolved oxygens importance for coral respiration and energy production these regions may be important for coral gardening and allow for productive coral restoration.</li>")
    }
    
    if ("Dissolved Organic Carbon " %in% top_vars) {
      explanation <- paste0(explanation, "<li><strong>Dissolved Organic Carbon:</strong><br/>
    <u>Significance:</u> the influence of dissolved organic carbon on live coral coverage may suggest the presence of either anthropogenic high levels of dissolved organic carbon from agricultural run-off, sewage or wastewater and industrial run-off. These can all cause elevated levels which negatively influence live coral coverage. Some habitats including mangroves and seagrass also elevate dissolved organic carbon and can potentially negatively influence live coral coverage.<br/>
    <u>Implications:</u> if the likely cause is anthropogenic this should be managed before any coral restoration is implemented in order to avoid the risk of any attempts failing. Coral monitoring programs should also be implemented to evaluate the effects.</li>")
    }
    
    if ("Aragonite Saturation " %in% top_vars) {
      explanation <- paste0(explanation, "<li><strong>Aragonite Saturation:</strong><br/>
    <u>Significance:</u> the influence of aragonite saturation on live coral coverage may suggest that high levels may allow for favorable coral growth conditions where corals can extrate carbonate from the surrounding water to build calcium carbonate structures easily.<br/>
    <u>Implications:</u> regions with high positive relationships between aragonite saturation and live coral coverage should be heavily considered for coral restoration and coral gardening as the attempts are more likely to be successful.</li>")
    }
    
    if ("Ammonia " %in% top_vars) {
      explanation <- paste0(explanation, "<li><strong>Ammonia:</strong><br/>
    <u>Significance:</u> the influence of ammonia on live coral coverage may suggest high input from coastal systems and waterways or from high levels of fish excretion. It has been suggested that despite this nutrient sometimes being linked to algal blooms which deplete the oxygen levels and prevent light penetration, ammonia can also dampen bleaching severity by preventing the build-up of molecules that signal metabolic stress.<br/>
    <u>Implications:</u> the regions where ammonia is an influential factor may be examined as a good location for coral restoration especially for species that are not considered thermally tolerant as the ammonia levels could assist with dampening bleaching severity of restored areas.</li>")
    }
    
    if ("Chlorophyll" %in% top_vars) {
      explanation <- paste0(explanation, "<li><strong>Chlorophyll:</strong><br/>
    <u>Significance:</u> the influence of chlorophyll on live coral coverage may suggest the impact of algae often in the form of algal blooms which deplete the oxygen levels and prevent light penetration. They can also often be attributed to high levels of terrestrial runoff and excess nutrients.<br/>
    <u>Implications:</u> prior to implementation of coral restoration, if chlorophyll is an issue for live coral coverage ensure the cause of the high chlorophyll is determined and solved. For this region coral monitoring and restoration is probably the best recommendation.</li>")
    }
    
    explanation <- paste0(explanation, "</ul>")
    
    HTML(explanation)
  })
  
  
  output$central_map <- renderLeaflet({
    req(input$shelfposition_central)
    
    selected_data <- data %>%
      filter(sector == input$shelfposition_central)
    
    pal <- colorNumeric("YlGnBu", domain = c(-100, 100))
    
    leaflet(selected_data) %>%
      addTiles() %>%
      addCircleMarkers(
        lng = ~longitude,
        lat = ~latitude,
        radius = 6,
        color = ~pal(rel_resilience),
        fillOpacity = 0.8,
        stroke = FALSE,
        label = ~paste0(
          "<strong>Reef Name: </strong>", english_name, "<br/>",
          "<strong>Reef ID: </strong>", name, "<br/>",
          "<strong>Relative Resilience: </strong>", rel_resilience
        ) %>% lapply(htmltools::HTML)
      )%>%
      addLegend(
        position = "bottomright",
        pal = pal,
        values = c(-100, 100),
        title = "Relative Resilience",
        labFormat = labelFormat(suffix = ""),
        opacity = 1
      )
  })
  
  output$central_table <- renderTable({
    req(input$shelfposition_central)  
    
    variableimportancedata %>%
      filter(Sector == input$shelfposition_central) %>%
      select(Variable, Importance)%>%
      arrange(desc(Importance)) 
  })
  
  output$central_text <- renderUI({
    req(input$shelfposition_central)
    
    top_vars <- variableimportancedata %>%
      filter(Sector == input$shelfposition_central) %>%
      arrange(desc(Importance)) %>%
      slice(1:3) %>%
      pull(Variable)
    
    explanation <- "<ul>"
    
    if ("Salinity " %in% top_vars) {
      explanation <- paste0(explanation, "<li><strong>Salinity:</strong><br/>
    <u>Significance:</u> the influence of salinity on live coral coverage may suggest the impact of mainland run-off into the reef system causing declines in salinity and possible coral bleaching or it could suggest a trend in cyclone related coral destruction which simultaneously leads to changes in ocean salinity over a short term.<br/>
    <u>Implications:</u> regions where salinity is an influential predictor of live coral cover should consider if this is due to runoff from the land and therefore how this can be accounted for. Reef monitoring at sites that meet this description is recommended. If the influence of salinity is due to extreme rainfall or cyclone events then coral restoration is recommended as these events are often short term and not predictable.</li>")
    }
    
    if ("pH " %in% top_vars) {
      explanation <- paste0(explanation, "<li><strong>pH:</strong><br/>
    <u>Significance:</u> the influence of pH on live coral coverage may reflect the impact of ocean acidification, which reduces the availability of carbonate ions needed for coral calcification. Lower pH levels can hinder coral growth and weaken skeletal structures, increasing susceptibility to environmental stressors. Alternatively, fluctuations in pH may indicate localized chemical changes driven by biological activity, terrestrial runoff, or upwelling events.<br/>
    <u>Implications:</u> regions where pH is an influential predictor of live coral cover should assess whether changes stem from long-term ocean acidification trends or short-term localized disturbances. If ocean acidification is the key driver, mitigation strategies such as reducing carbon emissions and improving marine carbonate buffering should be considered. Coral restoration efforts may focus on selecting resilient species that exhibit adaptation to lower pH conditions. If pH variations are linked to runoff, land management practices should be evaluated to minimize pollutant influx, and reef monitoring programs should be expanded to track chemical stability.</li>")
    }
    
    if ("Nitrogen " %in% top_vars) {
      explanation <- paste0(explanation, "<li><strong>Nitrogen:</strong><br/>
    <u>Significance:</u> the influence of nitrogen on live coral coverage may suggest the presence of algal blooms or excess anthropogenic run off from the mainland. Nitrogen if in correct amounts may have a positive relationship with coral growth how this is a delicate balance that is often disturbed by agricultural runoff and catchment erosion which can intensify crown-of-thorns starfish outbreaks and reduce post-bleaching recovery rates.<br/>
    <u>Implications:</u> prior to coral restoration, the cause of nitrogen influencing live coral coverage should be explored and solved if its an ongoing anthropogenic issue as any restoration may fail without this type of intervention. Coral monitoring should also be a large focus for this region.</li>")
    }
    
    if ("Dissolved oxygen " %in% top_vars) {
      explanation <- paste0(explanation, "<li><strong>Dissolved Oxygen:</strong><br/>
    <u>Significance:</u> the negative influence of dissolved oxygen on live coral coverage may suggest the presence of algal bloom or low flow conditions which remove oxygen from the ecosystem and alter coral respiration and energy supply causing coral dealth.<br/>
    <u>Implications:</u> regions where dissolved oxygen is influencing live coral coverage should be explored as to what the cause is. If the relationship is positive due to dissolved oxygens importance for coral respiration and energy production these regions may be important for coral gardening and allow for productive coral restoration.</li>")
    }
    
    if ("Dissolved Organic Carbon " %in% top_vars) {
      explanation <- paste0(explanation, "<li><strong>Dissolved Organic Carbon:</strong><br/>
    <u>Significance:</u> the influence of dissolved organic carbon on live coral coverage may suggest the presence of either anthropogenic high levels of dissolved organic carbon from agricultural run-off, sewage or wastewater and industrial run-off. These can all cause elevated levels which negatively influence live coral coverage. Some habitats including mangroves and seagrass also elevate dissolved organic carbon and can potentially negatively influence live coral coverage.<br/>
    <u>Implications:</u> if the likely cause is anthropogenic this should be managed before any coral restoration is implemented in order to avoid the risk of any attempts failing. Coral monitoring programs should also be implemented to evaluate the effects.</li>")
    }
    
    if ("Aragonite Saturation " %in% top_vars) {
      explanation <- paste0(explanation, "<li><strong>Aragonite Saturation:</strong><br/>
    <u>Significance:</u> the influence of aragonite saturation on live coral coverage may suggest that high levels may allow for favorable coral growth conditions where corals can extrate carbonate from the surrounding water to build calcium carbonate structures easily.<br/>
    <u>Implications:</u> regions with high positive relationships between aragonite saturation and live coral coverage should be heavily considered for coral restoration and coral gardening as the attempts are more likely to be successful.</li>")
    }
    
    if ("Ammonia " %in% top_vars) {
      explanation <- paste0(explanation, "<li><strong>Ammonia:</strong><br/>
    <u>Significance:</u> the influence of ammonia on live coral coverage may suggest high input from coastal systems and waterways or from high levels of fish excretion. It has been suggested that despite this nutrient sometimes being linked to algal blooms which deplete the oxygen levels and prevent light penetration, ammonia can also dampen bleaching severity by preventing the build-up of molecules that signal metabolic stress.<br/>
    <u>Implications:</u> the regions where ammonia is an influential factor may be examined as a good location for coral restoration especially for species that are not considered thermally tolerant as the ammonia levels could assist with dampening bleaching severity of restored areas.</li>")
    }
    
    if ("Chlorophyll" %in% top_vars) {
      explanation <- paste0(explanation, "<li><strong>Chlorophyll:</strong><br/>
    <u>Significance:</u> the influence of chlorophyll on live coral coverage may suggest the impact of algae often in the form of algal blooms which deplete the oxygen levels and prevent light penetration. They can also often be attributed to high levels of terrestrial runoff and excess nutrients.<br/>
    <u>Implications:</u> prior to implementation of coral restoration, if chlorophyll is an issue for live coral coverage ensure the cause of the high chlorophyll is determined and solved. For this region coral monitoring and restoration is probably the best recommendation.</li>")
    }
    
    explanation <- paste0(explanation, "</ul>")
    
    HTML(explanation)
  })
  
  output$southern_map <- renderLeaflet({
    req(input$shelfposition_southern)
    
    selected_data <- data %>%
      filter(sector == input$shelfposition_southern)
    
    pal <- colorNumeric("YlGnBu", domain = c(-100, 100))
    
    leaflet(selected_data) %>%
      addTiles() %>%
      addCircleMarkers(
        lng = ~longitude,
        lat = ~latitude,
        radius = 6,
        color = ~pal(rel_resilience),
        fillOpacity = 0.8,
        stroke = FALSE,
        label = ~paste0(
          "<strong>Reef Name: </strong>", english_name, "<br/>",
          "<strong>Reef ID: </strong>", name, "<br/>",
          "<strong>Relative Resilience: </strong>", rel_resilience
        ) %>% lapply(htmltools::HTML)
      )%>%
      addLegend(
        position = "bottomright",
        pal = pal,
        values = c(-100, 100),
        title = "Relative Resilience",
        labFormat = labelFormat(suffix = ""),
        opacity = 1
      )
  })
  
  output$southern_table <- renderTable({
    req(input$shelfposition_southern)  
    
    variableimportancedata %>%
      filter(Sector == input$shelfposition_southern) %>%
      select(Variable, Importance)%>%
      arrange(desc(Importance)) 
  })
  
  output$southern_text <- renderUI({
    req(input$shelfposition_southern)
    
    top_vars <- variableimportancedata %>%
      filter(Sector == input$shelfposition_southern) %>%
      arrange(desc(Importance)) %>%
      slice(1:3) %>%
      pull(Variable)
    
    explanation <- "<ul>"
    
    if ("Salinity " %in% top_vars) {
      explanation <- paste0(explanation, "<li><strong>Salinity:</strong><br/>
    <u>Significance:</u> the influence of salinity on live coral coverage may suggest the impact of mainland run-off into the reef system causing declines in salinity and possible coral bleaching or it could suggest a trend in cyclone related coral destruction which simultaneously leads to changes in ocean salinity over a short term.<br/>
    <u>Implications:</u> regions where salinity is an influential predictor of live coral cover should consider if this is due to runoff from the land and therefore how this can be accounted for. Reef monitoring at sites that meet this description is recommended. If the influence of salinity is due to extreme rainfall or cyclone events then coral restoration is recommended as these events are often short term and not predictable.</li>")
    }
    
    if ("pH " %in% top_vars) {
      explanation <- paste0(explanation, "<li><strong>pH:</strong><br/>
    <u>Significance:</u> the influence of pH on live coral coverage may reflect the impact of ocean acidification, which reduces the availability of carbonate ions needed for coral calcification. Lower pH levels can hinder coral growth and weaken skeletal structures, increasing susceptibility to environmental stressors. Alternatively, fluctuations in pH may indicate localized chemical changes driven by biological activity, terrestrial runoff, or upwelling events.<br/>
    <u>Implications:</u> regions where pH is an influential predictor of live coral cover should assess whether changes stem from long-term ocean acidification trends or short-term localized disturbances. If ocean acidification is the key driver, mitigation strategies such as reducing carbon emissions and improving marine carbonate buffering should be considered. Coral restoration efforts may focus on selecting resilient species that exhibit adaptation to lower pH conditions. If pH variations are linked to runoff, land management practices should be evaluated to minimize pollutant influx, and reef monitoring programs should be expanded to track chemical stability.</li>")
    }
    
    if ("Nitrogen " %in% top_vars) {
      explanation <- paste0(explanation, "<li><strong>Nitrogen:</strong><br/>
    <u>Significance:</u> the influence of nitrogen on live coral coverage may suggest the presence of algal blooms or excess anthropogenic run off from the mainland. Nitrogen if in correct amounts may have a positive relationship with coral growth how this is a delicate balance that is often disturbed by agricultural runoff and catchment erosion which can intensify crown-of-thorns starfish outbreaks and reduce post-bleaching recovery rates.<br/>
    <u>Implications:</u> prior to coral restoration, the cause of nitrogen influencing live coral coverage should be explored and solved if its an ongoing anthropogenic issue as any restoration may fail without this type of intervention. Coral monitoring should also be a large focus for this region.</li>")
    }
    
    if ("Dissolved oxygen " %in% top_vars) {
      explanation <- paste0(explanation, "<li><strong>Dissolved Oxygen:</strong><br/>
    <u>Significance:</u> the negative influence of dissolved oxygen on live coral coverage may suggest the presence of algal bloom or low flow conditions which remove oxygen from the ecosystem and alter coral respiration and energy supply causing coral dealth.<br/>
    <u>Implications:</u> regions where dissolved oxygen is influencing live coral coverage should be explored as to what the cause is. If the relationship is positive due to dissolved oxygens importance for coral respiration and energy production these regions may be important for coral gardening and allow for productive coral restoration.</li>")
    }
    
    if ("Dissolved Organic Carbon " %in% top_vars) {
      explanation <- paste0(explanation, "<li><strong>Dissolved Organic Carbon:</strong><br/>
    <u>Significance:</u> the influence of dissolved organic carbon on live coral coverage may suggest the presence of either anthropogenic high levels of dissolved organic carbon from agricultural run-off, sewage or wastewater and industrial run-off. These can all cause elevated levels which negatively influence live coral coverage. Some habitats including mangroves and seagrass also elevate dissolved organic carbon and can potentially negatively influence live coral coverage.<br/>
    <u>Implications:</u> if the likely cause is anthropogenic this should be managed before any coral restoration is implemented in order to avoid the risk of any attempts failing. Coral monitoring programs should also be implemented to evaluate the effects.</li>")
    }
    
    if ("Aragonite Saturation " %in% top_vars) {
      explanation <- paste0(explanation, "<li><strong>Aragonite Saturation:</strong><br/>
    <u>Significance:</u> the influence of aragonite saturation on live coral coverage may suggest that high levels may allow for favorable coral growth conditions where corals can extrate carbonate from the surrounding water to build calcium carbonate structures easily.<br/>
    <u>Implications:</u> regions with high positive relationships between aragonite saturation and live coral coverage should be heavily considered for coral restoration and coral gardening as the attempts are more likely to be successful.</li>")
    }
    
    if ("Ammonia " %in% top_vars) {
      explanation <- paste0(explanation, "<li><strong>Ammonia:</strong><br/>
    <u>Significance:</u> the influence of ammonia on live coral coverage may suggest high input from coastal systems and waterways or from high levels of fish excretion. It has been suggested that despite this nutrient sometimes being linked to algal blooms which deplete the oxygen levels and prevent light penetration, ammonia can also dampen bleaching severity by preventing the build-up of molecules that signal metabolic stress.<br/>
    <u>Implications:</u> the regions where ammonia is an influential factor may be examined as a good location for coral restoration especially for species that are not considered thermally tolerant as the ammonia levels could assist with dampening bleaching severity of restored areas.</li>")
    }
    
    if ("Chlorophyll" %in% top_vars) {
      explanation <- paste0(explanation, "<li><strong>Chlorophyll:</strong><br/>
    <u>Significance:</u> the influence of chlorophyll on live coral coverage may suggest the impact of algae often in the form of algal blooms which deplete the oxygen levels and prevent light penetration. They can also often be attributed to high levels of terrestrial runoff and excess nutrients.<br/>
    <u>Implications:</u> prior to implementation of coral restoration, if chlorophyll is an issue for live coral coverage ensure the cause of the high chlorophyll is determined and solved. For this region coral monitoring and restoration is probably the best recommendation.</li>")
    }
    
    explanation <- paste0(explanation, "</ul>")
    
    HTML(explanation)
  })
  
  observeEvent(input$go_to_comparison, {
    updateNavbarPage(session, inputId = "navbar", selected = "Comparison")
  })
  
  observeEvent(input$go_to_map_overview, {
    updateNavbarPage(session, inputId = "navbar", selected = "Map Overview")
  })
  
  region_choices <- c(
    "Northern - Middle Shelf (NM)" = "NM",
    "Northern - Outer Shelf (NO)" = "NO",
    "Central - Middle Shelf (CM)" = "CM",
    "Central - Outer Shelf (CO)" = "CO",
    "Southern - Middle Shelf (SM)" = "SM",
    "Southern - Outer Shelf (SO)" = "SO"
  )
  
  output$comparison_ui <- renderUI({
    req(input$num_regions)
    
    columns <- lapply(1:as.numeric(input$num_regions), function(i) {
      column(
        width = floor(12 / as.numeric(input$num_regions)),  
        selectInput(paste0("region_code_", i), paste("Select Sector", i), choices = region_choices),
        leafletOutput(paste0("comparison_map_", i), height = 400),
        uiOutput(paste0("avg_resilience_", i)),
        br(),
        h4("Environmental Variables"),
        tableOutput(paste0("summary_table_", i))
      )
    })
    
    fluidRow(columns)
  })
  
  observe({
    req(input$num_regions)
    
    lapply(1:as.numeric(input$num_regions), function(i) {
      output[[paste0("comparison_map_", i)]] <- renderLeaflet({
        region_code <- input[[paste0("region_code_", i)]]
        req(region_code)
        
        selected_data <- data %>% filter(sector == region_code)
        
        pal <- colorNumeric("YlGnBu", domain = c(-100, 100))
        
        leaflet(selected_data) %>%
          addTiles() %>%
          addCircleMarkers(
            lng = ~longitude,
            lat = ~latitude,
            radius = 6,
            color = ~pal(rel_resilience),
            fillOpacity = 0.8,
            stroke = FALSE,
            label = ~paste0(
              "<strong>Reef Name: </strong>", english_name, "<br/>",
              "<strong>Reef ID: </strong>", name, "<br/>",
              "<strong>Relative Resilience: </strong>", rel_resilience
            ) %>% lapply(htmltools::HTML)
          )%>%
          addLegend(
            position = "bottomright",
            pal = pal,
            values = c(-100, 100),
            title = "Relative Resilience",
            labFormat = labelFormat(suffix = ""),
            opacity = 1
          )
      })
      
      output[[paste0("avg_resilience_", i)]] <- renderUI({
        region_code <- input[[paste0("region_code_", i)]]
        req(region_code)
        
        selected_data <- data %>% filter(sector == region_code)
        avg_res <- mean(selected_data$rel_resilience, na.rm = TRUE)
        
        HTML(paste0("<strong>Average Resilience: </strong>", round(avg_res, 2)))
      })
      
      output[[paste0("summary_table_", i)]] <- renderTable({
        region_code <- input[[paste0("region_code_", i)]]
        req(region_code)
        
        variableimportancedata %>%
          filter(Sector == region_code) %>%
          select(Variable, Importance) %>%
          arrange(desc(Importance))
      })
    })
  })
  
  
  
}

shinyApp(ui, server)