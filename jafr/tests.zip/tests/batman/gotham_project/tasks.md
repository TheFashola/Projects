# Gotham City

- Analyze Scarecrow's New Toxin Due: 03/09/23 not complete
- Update Batmobile Firmware Due: 04/09/23 complete

# Wayne Enterprises

- Review Q3 Financials Due: 04/09/23 not complete

# Bat Family

- Training Session with Robin Due: 05/09/23 complete
- Revisit Contingency Plans Due: 06/09/23 not complete

