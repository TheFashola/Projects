# Police Work

- Task Force Briefing on Two-Face Scheduled: 10:00 03/09/23

# Community

- Town Hall Meeting on Public Safety Scheduled: 18:00 04/09/23

# Interdepartmental

- Meeting with Mayor Scheduled: 13:00 04/09/23