# Police Duties

- Review Forensic Reports Due: 03/09/23 complete
- Budget Approval for Next Quarter Due: 04/09/23 not complete

# Personal

- Pick Up Birthday Gift for Barbara Due: 04/09/23 not complete

# Community

- Draft Speech for Town Hall Due: 05/09/23 not complete
- Review Neighborhood Watch Applications Due: 05/09/23 not complete

