# Current date: 03/09/23

## displaying_reminders:
- Current user is batman

## completing_tasks:
- Current user is alfred

## adding_meetings:
- Current user is gordon