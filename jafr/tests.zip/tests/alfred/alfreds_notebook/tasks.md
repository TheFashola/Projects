# Wayne Manor

- Polish Silverware Due: 03/09/23 complete
- Inspect Security Systems Due: 04/09/23 not complete

# Personal

- Read New Mystery Novel Due: 04/09/23 not complete

# Bruce Wayne

- Prepare Bruce's Suit for Charity Event Due: 05/09/23 not complete
- Update Medical Kit in Batcave Due: 05/09/23 complete

